# GoldPrice
## 必要条件
PowerShell中定位到程序根目录执行下面语句安装Playwright依赖
```
powershell -NoProfile -ExecutionPolicy Bypass `
  -File "playwright.ps1" install
```